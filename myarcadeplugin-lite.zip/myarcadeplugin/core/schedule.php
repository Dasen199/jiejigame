<?php
/**
 * Automated fetching and publishing
 *
 * @package MyArcadePlugin/Cron
 */

// No direct Access.
if ( ! defined( 'ABSPATH' ) ) {
	die();
}
