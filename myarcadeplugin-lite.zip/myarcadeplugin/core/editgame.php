<?php
// PRO Feature
myarcade_premium_message();
