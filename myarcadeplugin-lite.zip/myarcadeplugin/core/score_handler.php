<?php
/**
 * Game output functions
 *
 * @package MyArcadePlugin/Scores
 */



// No direct access.
if( ! defined( 'ABSPATH' ) ) {
  die();
}

// PRO
