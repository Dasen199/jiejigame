###########################################################################
#     GameMonetize.com CMS Installation  - Awesome Free Arcade Script!    #
###########################################################################


https://gamemonetize.com/blog/how-to-install-free-website-gaming-arcade-cms-gamemonetize-com
https://gamemonetize.com/blog/how-to-update-arcade-cms-from-lower-version-to-latest-version

v5.0.3 - fixed category link that show in google search console
v5.0.2 - fixed .io, .io games tag for canonical tag
v5.0.0 - WalkThrough, Blog, Youtube Hover icon, Tags, Description Footer all Page, SEO Title-Meta Description, Similar Games Left and right by game name, Fixed some bugs
v4.0.0 - sitemap.xml, feed, new box admin edit game, can publish 1 game, support PHP up to 8.2.


Follow this steps to setup GameMonetize.com CMS and in few minutes you will have this games platform running in your server.
Recommended Configuration: PHP +5.6 up to 8.2, in case not work on 8.2 try lower version, depend of your hosting, MySQL
If the installation fails, please delete the file config.php and install-blank.php (located at: /assets/includes/) and start again. :)

ALL 5 STEPS VIDEO: https://www.youtube.com/watch?v=Yq81IkuNZgw&ab_channel=BestCrazyGames

STEP 1:
Create a database

STEP 2:
Upload the files inside the "Upload" folder on your FTP or local host, you can install this script in root or subfolder, as you prefer. You only need to set the url to the root or subfolder

STEP 3:
Once you have uploaded all files on your server it is very simple to install it. If you have install GameMonetize.com CMS in root of your server simply open your browser then type in the adress of your chat host ex: http://mydomain.com or if you decided to use a subfolder simply go to ex: http://mydomain.com/subfolder/

STEP 4:
Simply follow these steps and in few minutes you will have a awesome arcade website GameMonetize.com CMS with thousands games for you exclusively for FREE!

STEP 5:
Enjoy GameMonetize.com Arcade CMS - An modern awesome arcade platform for all publishers with thousands games and daily newest games!


In CASE YOU HAVE ERROR ON INSTALL:
https://www.youtube.com/watch?v=zzL8QcTRbLQ&ab_channel=BestCrazyGames
- You might read this ON "Solution 3 � Disable Strict Mode": https://database.guide/5-ways-to-fix-error-1364-field-doesnt-have-a-default-value-in-mysql/
               -Sometimes Hosting not allow install custom website so you need to "Disable Strict Mode" to finish installation cms

--- CMS NOT WORK ON SUBDOMAIN.

Visit us:       https://gamemonetize.com
Join us:        https://gamemonetize.com/joinus
Games Catalog:  https://gamemonetize.com/games
How to install: https://gamemonetize.com/blog/how-to-install-free-website-gaming-arcade-cms-gamemonetize-com

###########################################################################
#              Credits: GameMonetize.com Copyright � 2021                 #
###########################################################################

GameMonetize.com � 2021 GMO Holding Ltd. - All Rights Reserved �

FAQ:
Where I can add a new theme?
In the /templates/ folder make a copy of the /kizi/ (template by default) and edit it. Use simple css code and create your own awesome arcade website!

Where I can edit the current theme?
Inside the /templates/YOUR-THEME are all necessary folders to edit the style and structure of the current theme.

THEMES AVAILABLE: (switch into your portal settings)
- kizi


NOTE:
PHP version +5.6  up to 8.2 is recommended

-SOME TUTORIAL SEO---
- when publish 100 games go to generate sitemap, when push button "Generate Sitemap" just wait untill refresh admin page or else will geretate duplicate sitemap
- if you plan to publish all games make sure you will rewrite all description for google SEO to rank UP
- we aded links inside each description game to integrate in your description
- we recommend daily to publish 7 to 15 games and all games description must be rewrited or no chance to rank in google
- publish daily games
- Walkthrough is automatic added to each game so you not need to do nothing
- each page have option to make description, we recommend to write all page in admin for seo and rank up, adding also internal link ad keywords in all description
- every time when publish 1 game rewrite and then submit to google search console, when your website get indexed by google automatic you not need to submit game link manual
- we have added BLOG



--------------CMS VESRION 6.0 IS NOW ON WORK :) ---------------

Contact us:           info@gamemonetize.com
Business inquiries:   katie@gamemonetize.com
Do you need any customization this arcade script? Reach us at: info@gamemonetize.com