<div class="gamemonetize-main span100">
	<div class="_a-c _e55">
		<div>
			<img src="{{CONFIG_THEME_PATH}}/image/icon-color/mustache.png">
		</div>
		<h3>@profile_not_found@</h3>
	</div>
</div>