<!DOCTYPE html>
<html>
<head>
{{HEADER_TAGS}}
</head>

<body>
    {{HEADER}}

    <div {{PAGE_THEATER_MODE}} class="gamemonetize-page-tree gamemonetize-container">
        {{PAGE_CONTENT}}
    </div>

    {{FOOTER}}
</body>
</html>