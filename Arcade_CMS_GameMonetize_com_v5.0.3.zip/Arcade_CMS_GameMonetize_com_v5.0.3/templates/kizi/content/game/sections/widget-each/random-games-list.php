<li>
    <a href="{{RANDOM_GAME_URL}}" class="game-item">
        <div class="gameicon" style="background-image: url({{RANDOM_GAME_IMAGE}});background-size: cover;background-position-x: 50%;background-position-y: 50%;"></div>
        <p class="post-name" data-url="{{RANDOM_GAME_VIDEO_URL}}" data-scale="1.2" data-translate="-37px,-30px">{{RANDOM_GAME_NAME}}</p>
    </a>
</li>