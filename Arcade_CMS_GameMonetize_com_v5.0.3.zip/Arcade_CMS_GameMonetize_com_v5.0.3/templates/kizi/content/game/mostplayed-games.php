<ul class="card">
	{{MOSTPLAYED_GAMES_LIST}}
</ul>