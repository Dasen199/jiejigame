<div class="ad728list">
{{ADS_TOP}}
</div>
{{GAMES_PLAYED}}

{{TAG_NAME}}

<div id="content">
    {{ADS_300}}

	{{NEW_GAMES_LIST}}
</div>

<div class="bgs bottomtext fn-clear" style="padding:20px; width:90% !important;">    
    {{FOOTER_DESCRIPTION}}
</div>