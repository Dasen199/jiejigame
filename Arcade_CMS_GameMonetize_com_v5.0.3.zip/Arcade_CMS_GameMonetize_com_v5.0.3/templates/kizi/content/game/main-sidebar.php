<div class="container-widget pull-right span30">
	{{ADS_SIDEBAR}}

	{{MAIN_SIDEBAR_WIDGETS}}
</div>