<div class="_b-t _10e4">
	<img class="img-circle _a6" src="{{STATS_USER_AVATAR}}" width="30">
	<div class="_a6 last-users-name">{{STATS_USER_NAME}}</div>
	<button class="pull-right btn-edit-user" data-href="{{CONFIG_SITE_URL}}/admin/users/edit/{{STATS_USER_USERNAME}}">
		<i class="fa fa-wrench icon-middle icon-18"></i>
	</button>
</div>