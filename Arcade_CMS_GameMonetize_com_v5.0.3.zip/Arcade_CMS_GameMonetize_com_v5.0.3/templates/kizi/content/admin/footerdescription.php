<div class="gamemonetize-main-headself">
	<i class="fa fa-bookmark"></i> FOOTER DESCRIPTION
</div>
{{FOOTER_DESCRIPTION_SECTION_CONTENT}}