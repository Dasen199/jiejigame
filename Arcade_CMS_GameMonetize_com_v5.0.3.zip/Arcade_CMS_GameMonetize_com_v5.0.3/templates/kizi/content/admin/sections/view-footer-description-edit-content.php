<div>
	<div style="margin: 10px 0;">
		Seo Description
	</div>
	<textarea rows="15" style="min-height: 339px;" name="content_value" class="editor-js _text-input _tr5 tinymce">{{EDIT_FOOTER_DESCRIPTION_VALUE_CONTENT_VALUE}}</textarea>
</div>