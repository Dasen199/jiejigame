<script type="text/javascript">
    var siteUrl = '{{HEADER_URL}}';
</script>