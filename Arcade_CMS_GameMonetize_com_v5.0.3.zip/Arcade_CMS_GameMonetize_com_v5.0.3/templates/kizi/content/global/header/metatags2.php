<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta http-equiv="x-dns-prefetch-control" content="on" />
<meta name="description" content="{{GAME_META_DESCRIPTION2}}">