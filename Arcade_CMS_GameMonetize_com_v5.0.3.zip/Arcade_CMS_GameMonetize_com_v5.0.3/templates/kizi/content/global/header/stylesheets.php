<link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/play.css">
<link rel="stylesheet" type="text/css" href="{{CONFIG_THEME_PATH}}/css/all.css?ver">
<script src="{{CONFIG_THEME_PATH}}/js/jquery.v1.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Droid+Sans:400,700|Oswald:400,700" rel="stylesheet" type="text/css">