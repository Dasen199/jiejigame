<div class="_a-c _e55" style="margin:0 auto;width: 90px;color: white;margin-top: 12px;">
	<div>
		<img style="position: relative;left: -12px;" src="{{CONFIG_THEME_PATH}}/image/icon-color/search.png">
	</div>
	<h3 style="margin-top: 17px;">@search_not_found@</h3>
</div>